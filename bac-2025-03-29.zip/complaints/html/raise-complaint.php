<div class="modal fade" id="raise_complaints_Modal" tabindex="-1" role="dialog" aria-labelledby="raise_complaints_Modal" aria-hidden="true">
  <div class="modal-dialog " role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Comaplaint Raise</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>
      <div class="modal-body">

        <div class="row justify-content-center " >
          <div class="col-12 d-flex align-items-center justify-content-center">

            <textarea class="form-control" maxlength="250" rows="4" cols="60"  id="new_complaint"></textarea> 
          </div>
          <div class="col-12 text-left mt-2">
            <small> The Complaint accepts up to 250 characters.</small>
          </div>
          
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="raise_new_complaint">Submit</button>
        <!--  <button type="button" class="btn btn-primary" id="" >Update</button> -->
        <!--   <button type="button" class="btn btn-secondary" id="btn_scd_update" >up</button> -->
      </div>
    </div>
  </div>
</div>