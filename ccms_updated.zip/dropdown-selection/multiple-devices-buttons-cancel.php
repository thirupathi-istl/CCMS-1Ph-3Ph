
<button type="button" class="btn btn-danger clear_multiple_selections" id="cancel_all" >Clear</button>