<?php
require_once 'config-path.php';
require_once '../session/session-manager.php';
SessionManager::logout();
?>