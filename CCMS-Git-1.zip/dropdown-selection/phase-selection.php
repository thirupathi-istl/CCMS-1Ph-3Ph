 <select class="form-select pointer" id="phase-selection" aria-label="Large select example">
 	<option value="ALL" >ALL-Phases</option>
 	<option value="3PH" >Three-Phase</option>
 	<option value="1PH" >Single-Phase</option>


 </select>