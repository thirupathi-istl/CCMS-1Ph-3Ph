 </div>

 <?php include(BASE_PATH."assets/html/session-out-warning.php");?>
 <script src="<?php echo BASE_PATH;?>assets/js/project/preloader.js"></script>
 <script src="<?php echo BASE_PATH;?>assets/js/project/group_list_update.js"></script>
 <script src="<?php echo BASE_PATH;?>assets/js/project/update-frame-time.js"></script>
 <script src="<?php echo BASE_PATH;?>assets/js/project/location_link.js"></script>
</body>